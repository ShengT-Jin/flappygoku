import java.util.concurrent.TimeUnit;

public class birdmove {//Shengtong,Jin this class is for the gonku cna fly and with different picture
	private	EZImage birdfly;//did not share
	private EZImage birdup;//did not share
	private EZImage birddown;//did not share
	int birdx = 0;
	int birdy = 0;
	int goal = 0;
	EZSound fly = EZ.addSound("fly.wav");
	static final int FLY= 1;
	static final int UP = 2;
	static final int DOWN = 3;
	
	int birdaction = FLY;
	birdmove(int x , int y){
		birdx=x;
		birdy=y;
	birdfly = EZ.addImage("bird.png", birdx, birdy);
	birdup = EZ.addImage("birdup.png", birdx, birdy);
	birddown = EZ.addImage("birddown.png", birdx, birdy);
		hidebird();
		birdfly.show();
	}
	void hidebird () {
		birdfly.hide();
		birdup.hide();
		birddown.hide();
	}
	void posbird (int x, int y) {
		birdfly.translateTo(x, y);
		birdup.translateTo(x, y);
		birddown.translateTo(x, y);
	}
	void birdmovement () throws InterruptedException {
		switch(birdaction) {
		case FLY:
			birdy+=3;
			if(EZInteraction.wasKeyPressed('c')) {
				birdaction = UP;
				fly.play();
				hidebird();
				birdup.show();
				goal = birdy - 100;
			} break;
		case UP:
			birdy-=2;
			if(EZInteraction.wasKeyPressed('c')) {
				birdaction = UP;
				hidebird();
				birdup.show();
				goal = birdy - 100;
			}
			if (birdy <= goal) {
			birdaction= DOWN;
			}
			break;
		case DOWN:
			hidebird();
			birddown.show();
			if(EZInteraction.wasKeyPressed('c')) {
				birdaction = UP;
				hidebird();
				birdup.show();
				goal = birdy - 100;
			}
			birdaction=FLY;
		}
		
	}
}
