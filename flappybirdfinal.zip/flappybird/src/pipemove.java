//create the EZImage of the tube and run the class in the main program
//made by Li Liang

import java.awt.Color;
import java.util.Random;

public class pipemove {
	Random RandomGenerator= new Random();
	EZRectangle tube = EZ.addRectangle(550, 150, 60,300, Color.green, true);
	EZRectangle tube1 = EZ.addRectangle(450,650,60,300, Color.green, true);
		

}
