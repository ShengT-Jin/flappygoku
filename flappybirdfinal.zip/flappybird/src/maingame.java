import java.io.FileReader;
import java.util.Random;
import java.util.Scanner;
import java.awt.Color;
public class maingame {

	public static void main(String[] args) throws java.io.IOException, InterruptedException {
		FileReader fr = new FileReader("level.txt");
		Scanner fileScanner = new Scanner(fr);
		int c = 1;
		int width = fileScanner.nextInt();
		int height = fileScanner.nextInt();
		String inputText = fileScanner.nextLine();
		EZ.initialize(width*32, height*32);
		EZ.setBackgroundColor(new Color(0,191,255));
		EZSound bm = EZ.addSound("bm.wav");
		EZText gamestar = EZ.addText(150, 600,"PRESS C TO Fly", new Color(1,1,1), 25);
		EZImage mypics[] = new EZImage[1000];
		Random RandomGenerator= new Random();
		EZRectangle tube = EZ.addRectangle(550, 150, 60,300, Color.green, true);
		EZRectangle tube1 = EZ.addRectangle(450,650,60,300, Color.green, true);
			
		
			
		int i = 0;
		for(int row = 0; row < height; row++){
			
			inputText = fileScanner.nextLine();	
			System.out.println(inputText);
	
		for (int column = 0; column < width; column++){
			
			char ch = inputText.charAt(column);   
	
			if (ch == 'a') {
				mypics[i] = EZ.addImage("c1.png",column*32,row*32);
			} else if (ch == 'b'){
				mypics[i] = EZ.addImage("c2.png",column*32,row*32);
			} else if (ch == 'c'){
				mypics[i] = EZ.addImage("c3.png",column*32,row*32);
			} else if (ch == 'G') {
				mypics[i] = EZ.addImage("g1.png",column*32,row*32);
			}
			i++;
			switch(ch){
			case 'a':
				EZ.addImage("c1.png",column*32,row*32);
				break;		
			case 'b':
				EZ.addImage("c2.png",column*32,row*32);
				break;
			case 'c':
				EZ.addImage("c3.png",column*32,row*32);
				break;
			case'G':
				EZ.addImage("g1.png",column*32,row*32);
			default:
				break;			
		}
		}
		}bm.play();
		birdmove mybird= new birdmove(100,500);
		
					
			while(true){
				
				
				for(i =0; i < (width*height);i++) {
					if (mypics[i] != null) {
						
						mypics[i].translateBy(-1,0);
						int x = mypics[i].getXCenter();
						int y = mypics[i].getYCenter();
						if (x < 0) {
							mypics[i].translateTo(width*32,y);
						
		}
						
			}

				} 
						tube.translateBy(-3,0);
						tube1.translateBy(-3,0);			
						if(tube.getXCenter()<0&&tube1.getXCenter()<0) {
							tube.translateTo(width*32,tube.getYCenter());
							tube1.translateTo(width*32+RandomGenerator.nextInt(300), tube1.getYCenter());
							
						}
					
				EZ.refreshScreen();
				mybird.birdmovement();
				mybird.posbird(mybird.birdx, mybird.birdy);
				
			}
	}
}
		
	
		
	

